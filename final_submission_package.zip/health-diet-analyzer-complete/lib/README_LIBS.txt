For JSON support, download gson (e.g., gson-2.8.9.jar) and place it here, then compile with classpath including lib/*
